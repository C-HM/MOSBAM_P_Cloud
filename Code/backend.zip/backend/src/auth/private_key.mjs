const privateKey = "CUSTOM_PRIVATE_KEY";
export { privateKey };
