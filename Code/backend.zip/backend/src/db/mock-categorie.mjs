let categories = [
  { categorie_id: 1, nom: "Roman" },
  { categorie_id: 2, nom: "Fantasy" },
  { categorie_id: 3, nom: "Manga" },
  { categorie_id: 4, nom: "Essai" },
  { categorie_id: 5, nom: "Animés" },
  { categorie_id: 6, nom: "BD" },
  { categorie_id: 7, nom: "Aventure" },
];

export { categories };
