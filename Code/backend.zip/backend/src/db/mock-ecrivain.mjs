let ecrivains = [
  { id: 1, nom: "Martin", prenom: "Jean" },
  { id: 2, nom: "Dubois", prenom: "Sophie" },
  { id: 3, nom: "Lemoine", prenom: "Alexandre" },
  { id: 4, nom: "Morel", prenom: "Camille" },
  { id: 5, nom: "Girard", prenom: "Lucas" },
  { id: 6, nom: "Rousseau", prenom: "Emma" },
  { id: 7, nom: "Leclerc", prenom: "Julien" },
  { id: 8, nom: "Bertrand", prenom: "Marie" },
  { id: 9, nom: "Robin", prenom: "Thomas" },
  { id: 10, nom: "Dupont", prenom: "Laura" },
];

export { ecrivains };
